# brand-agent

An agent skill for running a **brand agent**: one git repo per brand that
makes quality, brand-consistent content at scale. It holds the brand (tokens,
rules, approved examples) and the tools that turn one idea into finished work
for every platform, from carousels and decks to video. Additionally it can
publish organic posts and connect to Meta Ads for paid social.

Written up at https://www.joshmaldonado.com/notes/the-brand-agent

## Install

Works in any agent that reads SKILL.md skills: Claude Code, Codex, Hermes.

```bash
unzip brand-agent.zip -d ~/.claude/skills/
cd ~/.claude/skills/brand-agent/scripts/static && npm install
# other agents: link the same folder into their skills directory
ln -s ~/.claude/skills/brand-agent ~/.codex/skills/brand-agent
```

Each brand repo keeps its instructions in `AGENTS.md` (read by Codex and
Hermes); `CLAUDE.md` is one line, `@AGENTS.md`, for Claude Code.

Requirements: Claude Code, Python 3, Node 18+, Google Chrome (for the HTML
renderer), git and git-lfs. Video work also wants ffmpeg; the skill points to
HyperFrames, Remotion, ElevenLabs and a transcript editor where they fit.

## Start a brand

```bash
python3 ~/.claude/skills/brand-agent/scripts/init_brand.py ~/Projects/acme-brand --name "Acme" --url acme.com
```

Then open the new repo in your agent and ask it to build the brand core
from your guidelines, then to design something. The skill takes it from there.

## What's inside

```
brand-agent/
  SKILL.md                 the method: content production, distribution, tracking, workflows, rules
  reference/               one file per layer
  templates/               repo skeleton: tokens.json, build.py, BRAND.md,
                           canon, CLAUDE.md, POST.md, channels.json,
                           design-system starter, .gitignore/.gitattributes
  scripts/init_brand.py    scaffold a new brand repo (git + LFS included)
  scripts/publish/publish.py  schedule a campaign (Postiz, hand-off, browser
                           checklist), always behind --confirm
  scripts/static/render.mjs  render any HTML design (incl. Claude Design
                           exports and decks) to PNG, one per frame
```
