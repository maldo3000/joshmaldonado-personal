---
name: brand-agent
description: Set up and run a brand agent - one git repo per brand that makes quality, brand-consistent content at scale with agents. It holds the brand (tokens, rules, approved examples) and the tools to design and produce for it - original designs, posts, carousels, decks, print, video, scheduling and ad reporting. Works in any coding agent (Claude Code, Codex, Hermes). Use when asked to start a brand repo from guidelines, design something new for a brand (a campaign look, key art, a layout, a deck), make on-brand content in a brand repo, sync a brand with Claude Design, render HTML designs to PNG, cut or edit a promo, recap, reel, teaser, ad or event video from footage and/or music, add branded graphics or cards over footage, cut to a song's beat, choose between HyperFrames and Remotion, deliver 4:5 / 9:16 / 16:9, schedule posts, or pull ad performance into creative decisions. The brand repo's own rules always beat this skill.
---

# Brand agent

A **brand agent** is a repository for one brand whose job is to make
quality, brand-consistent content at scale: many posts, many platforms, one
standard. It holds the brand, written down so an agent can follow it, and the
tools that turn one idea into finished work in every format each platform
needs. Any coding agent can run it (Claude Code, Codex, Hermes): the repo
guide is `AGENTS.md`, the tools are plain Python and Node, and design happens
in HTML, so no visual editor is required. People hand it a brief; agents
produce on-brand work; the brand files decide what "on-brand" means. Every
brand repo has the same shape, so the method below works for all of them.

## The shape: content production, distribution, tracking

| Part | Layer | What it is | Where |
| --- | --- | --- | --- |
| Content production | Brand core (the rules) | exact values + judgment + approved examples, adjustable in one place | `brand/tokens.json`, `BRAND.md`, `canon/` |
| Content production | Design system (the parts) | the rules as ready-made components and templates, synced to Claude Design | `design-system/` |
| Content production | Asset library (the materials) | marks, fonts, photography, footage, graphic elements; stock and generated audio when it runs short | `assets/` |
| Content production | Make: static | carousels, posts, stories, decks, print as HTML, rendered to PNG/PDF in every format | `social/`, `print/`, `decks/` |
| Content production | Make: video | short-form, explainers, cut-downs: cuts, motion graphics, captions, delivery | `video/` |
| Distribution | Publishing | organic: campaign manifests + interchangeable posting adapters, behind approval | `social/<campaign>/post.json`, `brand/channels.json` |
| Distribution | Paid social | Meta Ads MCP: paid campaigns and their performance (read-only unless the repo allows writes), fed back into canon | `ads/reports/` |
| Tracking | Foundation | git + LFS, `.env` keys, the agent guide | `AGENTS.md`, `.gitattributes` |

The core loop is one idea in, a coordinated set out (4:5, 9:16, 1:1, 16:9,
short video, cut-downs), every frame reviewed against the canon. Add
distribution when a brand needs it.

Details per layer, and how to check a repo against the standard:
`reference/architecture.md`.

## Always, before making anything

1. Read the repo's `AGENTS.md` (Claude Code reaches it through `CLAUDE.md`),
   then `BRAND.md`, then `canon/README.md`.
   **The repo's rules beat this skill.**
2. Values come from `brand/tokens.json` only. Never type a hex, a font name
   or a size that is not a token. Generated files say GENERATED; never edit
   them, change `tokens.json` and run `python3 brand/build.py`.
3. Match the canon, not just the rules. Rules say what is allowed; canon
   shows what right looks like. On values, tokens win; on feel, canon wins.
4. Ask what the deliverable is (format, size, where it goes) instead of
   assuming.

## Workflows

**New brand** (from guidelines, references, fonts, marks):
run `scripts/init_brand.py <path> --name "<Brand>"`, then follow
`reference/brand-core.md` to fill `tokens.json`, `BRAND.md` and `canon/`
from the guidelines, then `reference/design-system.md` to build and sync the
design system. Git and LFS are set up by the script (`reference/repo-setup.md`).

**New design** (a campaign look, key art, a new layout, a deck, a poster):
brief, three directions as HTML built from the design system, render them
side by side with `render.mjs <file> <out> --sheet`, compare against canon,
critique in writing, let the owner pick, then build every format and
promote what is reusable into templates and tokens. `reference/design.md`.

**Static piece from a template** (new copy, new size): start from a
`design-system/templates/` file, replace copy, render with
`node scripts/static/render.mjs <file.html> <outDir>`, then look at every
PNG before showing anyone. `reference/static.md`.

**Something designed in Claude Design**: export the project, drop it into
`canon/claude-design/` (if approved) or the channel folder, render it here.
Same HTML renders the same pixels. `reference/design-system.md`.

**Video**: pick the editing path from the state of the footage: raw and
speech-led, a transcript editor (video-use); raw and music-led, the promo
pipeline (ffmpeg on a beat grid); already locked and needing surgery (a word
out, pitch, shake, SFX), a hand-written ffmpeg finishing pass from the
untouched master. Graphics come from the motion engine that best fits the
piece (HyperFrames, Remotion, or plain code drawing frames straight to ffmpeg), starting
from the repo's default, as a transparent overlay. No brand is locked to a
tool. `reference/video.md` has both decision tables.

**Publish**: write the campaign's `post.json`, map accounts in
`brand/channels.json`, run `scripts/publish/publish.py <campaign> dry`, and
**never schedule or post without the owner naming the accounts and times.**
`reference/publish.md`.

**Learn**: pull ad data read-only into `ads/reports/YYYY-MM-DD-<slug>.md`
with the creative takeaway first. `reference/learn.md`.

## Rules that hold for every brand

- Look at your own output before showing it: render, open every frame,
  check overlaps, contrast, safe zones and type sizes.
- One motion engine per piece; footage is never cut inside a motion engine.
- Logos in HTML are `<img>` of a pre-colored file, never a CSS mask (some
  exporters drop masks and ship a solid shape).
- Keys live in the repo's `.env` (gitignored). Never print one, never copy
  one between repos.
- Read-only by default for anything that spends money or speaks publicly
  (ads, posting). Mutations need an explicit yes, every time.
- Commit after every finished piece. Media goes to Git LFS.
- No em or en dashes in on-screen copy for any brand.
