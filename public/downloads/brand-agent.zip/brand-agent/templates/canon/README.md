# Canon: what good looks like

Approved {{BRAND}} work, each with a note on why it works. Read this before
designing anything new: **match these, not just the rules.** When canon and
`brand/tokens.json` disagree on a value, tokens win; on feel, canon wins.

Render any HTML piece with:

```bash
node ~/.claude/skills/brand-agent/scripts/static/render.mjs "<file>.html" <outDir>
```

## <Channel>

**<Piece name>**, `<path>`. One line on what it is.
- Works because ... (name the move: what repeats, what varies).
- Works because ...
- Known defect, if any, so nobody copies it.
