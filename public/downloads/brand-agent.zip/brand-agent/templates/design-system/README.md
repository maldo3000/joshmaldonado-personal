# {{BRAND}} design system

The {{BRAND}} brand as reusable HTML: tokens, component classes, preview cards
and templates measured from approved work. **Read `BRAND.md` first.**

## Build with it

1. Link `components.css` (it imports `tokens.css`).
2. Start from a file in `templates/`; replace copy, keep structure.
3. Every frame is a fixed-size element with `data-screen-label`
   (`.b-post` 1080x1350, `.b-story` 1080x1920, `.b-square`, `.b-slide` 1920x1080).
4. Use only the classes and `var(--b-*)` tokens: no new colors, fonts or effects.

Generated from the brand repo (`brand/tokens.json`, `BRAND.md`, `canon/`).
Change the brand there, not here.
