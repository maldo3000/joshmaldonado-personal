# <Campaign name>

Source: `<design file>` rendered to the platform folders beside this file.
Status: draft | approved | scheduled | posted

| Channel | When (timezone) | Media | Adapter | Status | Post id |
| --- | --- | --- | --- | --- | --- |
| instagram | Tue 29 Sep 5:10 PM EDT | instagram/01.png, instagram/02.mp4 | postiz | draft | |
| linkedin-page | Wed 30 Sep 9:00 AM EDT | linkedin/01.png | postiz | draft | |

## Captions

### instagram

<caption in the brand's voice>

### linkedin-page

<caption>

## Log

- <date>: dry run OK / approved by <name> / scheduled / posted / failed (why)
