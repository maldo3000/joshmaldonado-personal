# {{BRAND}} brand repo: agent guide (all agents)

This repo is the {{BRAND}} **brand agent**: the brand plus the tooling that
turns it into finished work. Every asset for the brand passes through here,
whatever the medium. Method: the `brand-agent` skill. This repo's rules beat it.

## Read first

1. `BRAND.md`: rules, voice, the canon's visual moves.
2. `canon/README.md`: approved work and why it works.
3. `brand/tokens.json`: every exact value. Never type a value that is not a
   token. After editing it, `python3 brand/build.py`; never edit GENERATED files.

Ask what the deliverable is (format, size, where it goes) before making it.

## Channels

| Folder | What | Tools |
| --- | --- | --- |
| `design-system/` | Claude Design design system, built from the core | `/design-sync` |
| `social/<campaign>/` | posts, carousels, stories + `POST.md` | HTML templates, render.mjs |
| `video/` | (add when needed) | |
| `print/` | (add when needed) | |
| `ads/reports/` | (add when needed) read-only performance | |

## Rules

- Commit after every finished piece. Media is in Git LFS.
- Keys are in `.env` (gitignored). Never print or copy one.
- Never post, schedule or change anything on a live platform without an
  explicit yes for those posts, accounts and times.

## Gotchas

(Add what bites in practice, with the fix.)
