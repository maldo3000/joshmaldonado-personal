# {{BRAND}} onboarding (in progress)

The brand agent is not ready yet. Any agent opening this repo: continue
onboarding before making anything for publication. Method: the `brand-agent`
skill, `reference/onboarding.md`. Delete this file when onboarding is done;
every decision belongs in `brand/tokens.json`, `BRAND.md` or `canon/`.

## Stage

- [ ] 1. The ask sent
- [ ] 2. Materials ingested and inventoried
- [ ] 3. Core drafted (tokens, BRAND.md, canon notes)
- [ ] 4. Played back and corrected
- [ ] 5. Three proof pieces approved
- [ ] 6. Ready

## Materials received

(What arrived, where it was filed, anything unusable and why.)

## Sources for drafted values

(Value, where it came from, confirmed or still a guess.)

## Open questions

(Five at most per round, each one that changes what gets made.)

## Decisions

(Owner's answers, dated, until they are written into the core.)
