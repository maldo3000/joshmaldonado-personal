# {{BRAND}}: brand

Read this before making anything, in any medium.

| File | Holds | When they disagree |
| --- | --- | --- |
| `brand/tokens.json` | exact values: color, type, sizes, formats | wins on values |
| `BRAND.md` (this) | judgment: voice, hierarchy, do and don't | wins on rules |
| `canon/` | approved work with notes on why it works | wins on feel |

Source documents: `guidelines/`.

## Who it is

One paragraph: what the brand is, who it speaks to, the tagline, and the
feeling in three words.

## Voice

- Language(s) and which leads.
- Tone in two or three plain phrases. Words to use, words to avoid.
- Punctuation rules (exclamation marks? dashes?).
- Fixed names and details (product names, handles, addresses).

## The mark

- Lockups and when each is used. Files in `assets/brand/`.
- Color rules, clear space, minimum size.
- Never: stretch, rotate, recolor outside the palette, effects.
- In HTML, place the mark as an `<img>` of the colored file, never a CSS mask.

## Color

Families and the ground rule (what can be a ground, what is accent only).
Values live in `brand/tokens.json`.

## Type

The voices, in order, and what each is for. One display headline per frame.
Sizes per canvas: `typeScale` in `brand/tokens.json`.

## How it looks in practice

The 5-10 moves that make the canon look like this brand. Study `canon/`:
what repeats across pieces? Name each move concretely.

1. ...
2. ...

## Layout

Margins per canvas, safe zones, grids, panels, icons.

## Motion

Pace, easing, what never happens (bounces, snaps). Frame rate.
