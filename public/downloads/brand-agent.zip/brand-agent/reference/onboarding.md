# Onboarding: from a pile of brand material to a brand agent that can produce

Onboarding is a conversation, not a form. The owner hands over whatever they
have; the agent sorts it, drafts the brand, shows it back, asks only what
changes the output, and proves the result with real pieces. It ends when the
repo can produce on-brand work without the owner re-explaining the brand.

Run it for every new brand (right after `scripts/init_brand.py`) and for an
existing folder being adopted as a brand agent. It can span several sessions:
`ONBOARDING.md` at the repo root holds the progress, the materials received
and the open questions, and any agent resumes from it. When onboarding is
done, every decision lives in `tokens.json`, `BRAND.md` or `canon/`, and
`ONBOARDING.md` is deleted.

## How to run the conversation

- **Ask for everything at once, accept anything.** One request for the whole
  pile beats twenty small questions. Partial is fine; start with what arrives.
- **Show, don't ask.** Draft a value from the evidence and show it ("the blue
  in the logo and on the site is #1E2BFA; using it as the primary"), so the
  owner corrects rather than invents. Ask open questions only where the
  material is silent or contradicts itself.
- **Five questions per round at most**, each one that would change what gets
  made (which of two blues leads, whether the logo may sit on photos, whether
  a rewrite sounds right). Never ask what the material already answers.
- **Every value has a source.** While drafting, note where each value came
  from in `ONBOARDING.md` (guide p.12, site CSS, measured from canon piece
  3). Unsourced guesses are labelled as guesses until the owner confirms.
- **Corrections go into the core, never only into a piece.** If a proof piece
  is wrong, fix the rule or value that produced it, then re-render.

## Stage 1: the ask

Send one message listing what helps, most valuable first, and say that
anything is welcome and gaps are fine:

1. Brand guidelines, any form: PDF, Figma, a Claude Design project, a deck,
   a doc, a page of notes.
2. Marks: logo, wordmark, symbol, ideally vector, in every colorway they have.
3. Fonts: the files and their licences (or the names, if they are Google or
   Adobe fonts).
4. The best existing work, 10-30 pieces: posts, carousels, decks, ads, video,
   print. Mark favourites and anything they dislike.
5. Imagery: photo library, footage, illustrations, icons, textures; and what
   they would never use (stock, AI images, certain styles).
6. Voice: website copy, captions, emails, scripts, and a line or two they
   wish they had written.
7. Where it goes: channels, accounts, formats, languages, cadence.
8. Hard rules: legal lines, words they never use, colors or competitors to
   avoid.
9. Website URL and social handles.

## Stage 2: ingest and inventory

File everything where it belongs: guidelines into `guidelines/` (never
edited), marks into `assets/brand/`, fonts into `assets/fonts/` with their
licences, imagery and footage into `assets/`, finished work into
`canon/candidates/`. Then read it all:

- **Guidelines**: extract values (hex, type, sizes, clear space) and rules.
  Note where the guide contradicts the work people actually shipped.
- **Website**: open it in a browser; take the computed colors, font families
  and weights from the live CSS, and screenshot the key pages. A live site is
  often the most accurate record of the brand in use.
- **Existing work**: lay it side by side (`render.mjs --sheet` for HTML, a
  contact sheet for images) and look for what repeats: grounds, margins,
  type pairings, how photos are treated, where the logo sits.
- **Fonts**: confirm each licence allows embedding and video; flag any font
  without a file or a licence.

Write the inventory and the gaps into `ONBOARDING.md`, then send the owner a
short summary: what arrived, what it says about the brand in a few lines, and
what is missing that matters.

## Stage 3: draft the core

Build the first full draft without waiting for answers, following
`brand-core.md`: `tokens.json` (every value with its job in `$description`),
`BRAND.md` (who it is, voice with do and don't examples, mark, color, type,
and "How it looks in practice"), and `canon/README.md` with a why-it-works
note per piece promoted from `canon/candidates/`. Run `python3 brand/build.py`.

## Stage 4: play it back

Show the draft as something the owner can see, not as files: render the
design system's foundation cards (colors, type, marks) and two or three
pieces of canon side by side with `render.mjs --sheet`, plus the voice as
three short rewrites of their own copy (a caption, a headline, a CTA). Then
ask the round's questions (five at most). Fold the answers in, note them in
`ONBOARDING.md`, and play back again only what changed. Two or three rounds
is normal.

## Stage 5: prove it

Build the design system (`design-system.md`) and make three real pieces from
one real brief, in different formats: a 4:5 post or carousel slide, a 9:16
story, and a 16:9 slide or a short video card. Review every frame against the
canon before showing them. The owner's reaction is the test: every correction
becomes a change to the core, then the pieces re-render from it. Repeat until
a round of proofs needs no rule or value changes, only copy.

## Stage 6: ready

Ready means another agent, starting cold, could make an approved piece. Check
by judgment, not by script:

- Tokens cover color (with jobs), type (families, preferred weights, the
  measured scale), layout (margins, safe zones) and the formats the brand
  ships.
- `BRAND.md` has the voice with real do and don't examples, the mark rules,
  and five or more concrete moves drawn from canon.
- Canon has enough approved pieces to show the moves, each with a note.
- Marks exist in the colorways the moves need; every font loads and is
  licensed; imagery is filed, with the rules on what is never used.
- The design system builds, renders, and is synced if the brand uses Claude
  Design; the three proof pieces were approved.
- Anything still undecided is either parked in `BRAND.md` as an open default
  ("blue leads until the rebrand lands") or dropped.

Then delete `ONBOARDING.md`, add the brand to this skill's brand list if it
keeps one, commit, and tell the owner the brand agent is ready, with the one
or two things it will still ask about.
