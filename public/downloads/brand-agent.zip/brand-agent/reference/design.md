# Design: originating work in the repo

Templates are for production (new copy, new formats, new sizes). This is for
**new design**: a campaign look, key art, a new layout, a deck, a poster.
It runs in any agent that can edit files and run the renderer; no visual
editor is required. Claude Design is an optional second surface, not the
place design has to happen.

## The loop

1. **Brief.** Write `social/<campaign>/design/BRIEF.md`: the one message,
   the audience, where it runs (formats), what must appear (date, CTA,
   logo), and which canon pieces are the closest reference. Ask the owner
   what you cannot infer.
2. **Study.** Render the referenced canon pieces and the relevant
   design-system cards (`render.mjs ... --sheet`). Name the moves you will
   keep from `BRAND.md` "How it looks in practice".
3. **Diverge: three directions.** One HTML file per direction in
   `design/`, e.g. `a-quiet.html`, `b-loud.html`, `c-photo-led.html`.
   Each is a real composition at the primary format, built from
   `design-system/components.css` classes and `var(--…)` tokens. New
   layouts are welcome; new values are not (no hex, font or size outside
   `brand/tokens.json`). Directions must differ in idea (hierarchy, image
   role, rhythm), not just in color.
4. **Compare.** Render every direction with `--sheet` and put the sheet
   beside a canon sheet. Look at them together, the way a person would.
5. **Critique** each direction, in writing, in `design/CRITIQUE.md`:
   - Does it use the canon's moves, or only the palette?
   - One message, one focal point, one accent?
   - Type voices in the brand's order; sizes at or above the minimums?
   - Safe zones, contrast, the logo actually rendered?
   - Would it sit next to the canon without looking like another brand?
   If a design-critique skill is installed (for example `impeccable`), run
   it on the rendered frames as a second opinion.
6. **Show the owner** the sheet and a one-line case for each direction.
   Recommend one. Do not continue past this point without their pick.
7. **Converge.** Refine the chosen direction, then build every format the
   brief needs (re-layout per format, never crop one). Render, look at every
   frame, fix, render again.
8. **Promote.** When the owner approves the finished piece:
   - add it to `canon/README.md` with a note on why it works;
   - if it introduced a reusable layout, turn it into a template in
     `design-system/templates/` (classes only, placeholder copy) and, if a
     new pattern, a class in `components.css` and a card;
   - if it needed a new value (a new accent, a size), add it to
     `brand/tokens.json` first and rebuild; never leave a value in the HTML.
   Commit. Re-sync Claude Design if the brand uses it.

## When the look itself changes

Exploring a new display face, a new accent for a new volume, a new photo
treatment: do it as directions in `design/` with the candidate value set
locally at the top of the file (`:root { --candidate-display: "…"; }`), so
it is obviously provisional. Once the owner decides, the value moves into
`brand/tokens.json` and `BRAND.md`, `build.py` runs, and every engine gets
it. Nothing is final until it is a token.

## Working with Claude Design as well

Both surfaces start from the same design system. Work can start on either
side; whichever side it starts on, the approved result lands in the repo
(`canon/`, templates, tokens), because that is the copy every agent reads.
See `design-system.md` for the sync.
