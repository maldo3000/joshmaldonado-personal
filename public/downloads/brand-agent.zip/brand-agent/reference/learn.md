# Learn

Performance data exists to change the next piece.

- Connect ad platforms **read-only** (for Meta, the hosted Ads MCP server at
  `https://mcp.facebook.com/ads`, wired in the repo's `.mcp.json`). Deny every
  mutating tool in `.claude/settings.json`; media buying is a separate
  project with its own approvals.
- Name ads after the design file that made them (`<docId>/<format>`) so data
  joins back to creative.
- Write each pull to `ads/reports/YYYY-MM-DD-<slug>.md`. First paragraph:
  the creative takeaway and exactly what to change in the next piece.
- When a pattern holds across reports, promote it: a winning piece goes into
  `canon/` with a note, a rule goes into `BRAND.md`.
