# Brand core: tokens.json, BRAND.md, canon

## Who wins

| File | Holds | Wins on |
| --- | --- | --- |
| `brand/tokens.json` | exact values | values (a hex, a font, a size) |
| `BRAND.md` | judgment, voice, do and don't | rules |
| `canon/` | approved work + notes | feel |

The guidelines in `guidelines/` are the source all three are built from. When
approved work disagrees with the guidelines on a value (a slightly different
olive in a deck), the guidelines' value goes in `tokens.json` and the piece
stays in canon for its look.

## tokens.json

W3C Design Tokens format: every leaf is `{ "$type", "$value", "$description" }`.
Start from `templates/brand/tokens.json`. Groups that matter in practice:

- `color`: each brand color with its job in `$description` ("labels, icons,
  rules"), not just its name.
- `font`, `fontWeight`, `tracking`: families as `[family, generic]`.
- `typeScale`: px per canvas (`social` at 1080 wide, `slide` at 1920x1080),
  **measured from canon**, not invented.
- `layout`: margins, safe zones (9:16 usually keeps 250px top and bottom),
  rule sizes, radius.
- `overlay`: alpha values for type over imagery, if the brand does that.
- `format`: the canvases the brand ships.

`brand/build.py` (from `templates/brand/build.py`) generates a CSS variables
file and a TypeScript object for every output listed in its `OUTPUTS`, and
copies fonts, marks and `BRAND.md` into `design-system/`. `--check` exits 1
when a generated file is stale; run it before committing.

## BRAND.md

Sections, in order (template: `templates/BRAND.md`):
1. A table of the three core files and who wins.
2. **Who it is**: one paragraph, the tagline, the feeling in three words.
3. **Voice**: language order, tone, words to use and avoid, punctuation
   rules, names and fixed details.
4. **The mark**: lockups, color rules, clear space, never-list, how to
   place it in HTML.
5. **Color**: families and the ground rule. Point to tokens for values.
6. **Type**: the voices in order and what each is for.
7. **How it looks in practice**: the 5-10 moves that make the canon look
   like the brand. Write these by studying the canon: what repeats across
   pieces? This section is what turns in-palette into on-brand.
8. **Layout** and **Motion**.

## canon/

`canon/README.md` lists each approved piece with a path and 2-4 bullets on
**why it works**: what it repeats, what it varies, what it refuses to do.
Include known defects honestly (an export that dropped the logo) so nobody
copies them. Good notes name the move ("grounds alternate, frame stays
fixed"), not the adjective ("clean, elegant").

Sources for canon: the brand's Claude Design project (export it, mirror into
`canon/claude-design/`, never edit the mirror), finished video projects,
print finals, posted social.
