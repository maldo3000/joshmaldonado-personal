# Publish

Three parts, so any one can change without touching the others. One tool
drives them: `scripts/publish/publish.py`.

## 1. The campaign: social/<campaign>/post.json (+ POST.md)

`post.json` is what the tool reads (template: `templates/social/post.json`):
one entry per post with `channel`, `date` (ISO with a UTC offset), `media`
(paths relative to the campaign folder), and `caption` (a string, a list for
an X thread, or `captionFile`). Optional per post: `title` (TikTok),
`settings` (platform overrides). After scheduling, the tool writes the post
ids back under `scheduled`.

`POST.md` stays as the human log: what was approved, by whom, what happened.

## 2. The brand's accounts: brand/channels.json

Each account: `id` (what posts reference), `platform`, `handle`, `adapter`,
and for Postiz the `postizIntegration` id (`publish.py <campaign> list`
prints them). `defaults.requireApproval` should stay true.

## 3. Adapters

| Adapter | How | Use when |
| --- | --- | --- |
| `postiz` | Postiz public API, key `POSTIZ_KEY` in the repo `.env` | the account is connected in Postiz |
| `browser` | `publish.py <c> browser` prints a checklist; an agent works the platform's own scheduler in a browser or with computer use | the account is not in a scheduler |
| `handoff` | `publish.py <c> handoff` writes `handoff/<channel>/` with media, caption, time | anything else, or when in doubt |

## Commands

```bash
P=~/.claude/skills/brand-agent/scripts/publish/publish.py
python3 $P social/<campaign> list                 # posts + live integrations
python3 $P social/<campaign> dry                  # payloads, nothing uploaded
python3 $P social/<campaign> schedule --confirm   # only after the owner's yes
python3 $P social/<campaign> update --confirm     # edit queued posts in place
python3 $P social/<campaign> status               # state after publish time
```

`schedule` and `update` refuse without `--confirm`. Pass it only after the
owner approved **these posts, these accounts, these times** in the
conversation. `--only x,linkedin` narrows any command.

## Platform notes

- Instagram carousels cap at 10 items (11 fails silently as ERROR).
  Carousel video wants yuv420p limited range + an AAC track.
- Keep uploads under ~40 MB; bigger files can break the upload mid-transfer.
- Editing a queued post: `update` re-reads each post's current group (it
  changes whenever the post is re-saved in the Postiz editor) and resends
  caption, media and date, because Postiz rewrites all three.
- Instagram failures only email "ERROR" and there are no failure webhooks:
  run `status` after publish time.
