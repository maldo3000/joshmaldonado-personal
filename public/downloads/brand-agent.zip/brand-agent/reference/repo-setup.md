# Repo setup: git + LFS

`scripts/init_brand.py` does all of this for a new repo. For an existing
folder without `.git`, follow the steps by hand.

## The rule

- **Plain git**: text, code, JSON recipes, HTML, CSS, fonts.
- **Git LFS**: images, video, audio, PDFs, Office and Keynote files, zips,
  and any self-contained HTML bundle over ~5 MB.
- **Ignored**: anything a script rebuilds (renders, previews, proxies, work
  dirs, exports, `node_modules`), stock downloads, `.env`, raw camera
  sources (back those up outside git).

## Steps

```bash
cp ~/.claude/skills/brand-agent/templates/repo/gitignore .gitignore
cp ~/.claude/skills/brand-agent/templates/repo/gitattributes .gitattributes
git init -b main && git lfs install --local
```

1. Measure before staging: plain git should be a few MiB; anything non-LFS
   over ~5 MB means a missing pattern.
2. Scan non-media files for secrets before the first commit.
3. Commit.
4. A remote (GitHub) is optional and per brand: push only the brands you
   work on from more than one machine. LFS storage on GitHub is metered
   across the whole account and is only freed by deleting the repo.
