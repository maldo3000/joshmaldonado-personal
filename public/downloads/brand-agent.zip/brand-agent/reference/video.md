# Video

## Who does what

| Job | Tool |
| --- | --- |
| Cut footage to music | ffmpeg, driven by a cut list in beats |
| Cut footage on speech (talking head, interview) | a transcript-driven editor (e.g. the video-use skill) |
| Read a track: beats, drop, phrases | librosa beat grid |
| Graphics over footage: titles, lists, lower thirds, end cards | the repo's motion engine, rendered as an alpha overlay |
| Transcripts, voiceover, music beds | ElevenLabs (Scribe, TTS, Music) |
| Captions | last, over the finished cut |

## Pick the editing path

Every path ends in ffmpeg; they differ in how much structure sits on top.
Decide from the state of the footage, not from the kind of video, and write
the choice in the project's notes.

| The footage is... | Path | Why |
| --- | --- | --- |
| Raw, and the edit is driven by what is said (talking head, interview, testimonial, first cut of a recap) | **Transcript editor** (video-use): word-level transcript, plain-English plan, edit list, its render | Picking takes and cutting on word boundaries is its whole job; pad, fade and subtitle-order rules are built in |
| Raw, and the edit is driven by a track (promo, teaser, montage, anything beat-locked) | **Promo pipeline**: beat grid, cut list in beats, ffmpeg cut, card template | Cuts land on the grid; one cut list masters every format |
| Already edited and locked (someone else's final, a client cut), needing surgery inside it | **Hand-written ffmpeg finishing pass**: one scripted filter graph from the untouched master | A transcript editor only picks and orders segments; removing one word, pitch or speed on a word, shake, compositing overlays and adding SFX are outside it |
| None, motion only (title card, sting, lower-third pack) | **Motion engine alone** | No cut to make |

Rules for the finishing pass, because no tool enforces them for you:

- One script rebuilds the whole piece from the untouched master every round.
  Never re-encode a previous output.
- Cut sound on word edges with short crossfades (about 30ms), and keep picture
  cuts on the beat by taking the same length out of a neighbouring shot's tail.
- Put every input on one frame clock before compositing (rendered overlays
  often carry a different timebase and swap frames otherwise).
- Prove each change by measurement before showing it: frame count, a still at
  every touched moment, a fresh transcript across any word cut, and peak
  levels for any added sound against the source.

Paths combine: the transcript editor cuts the raw interview, the motion
engine renders the graphics, and a finishing pass composites and mixes.
Speech timing comes from the transcript (word starts and ends); exact edges
come from audio analysis (librosa: onsets, syllable gaps, beats). The agent
cannot hear, so both are needed.

## Pick the motion engine, one per piece

No brand is locked to a tool. Every repo has a **default** engine (the one its
existing work and token files are built on, see the repo's guide); start
there, and switch for a piece when these criteria favor another. Write the
choice and the reason in the project's notes.

| The piece is... | Best fit | Why |
| --- | --- | --- |
| Timeline graphics over footage: titles, kinetic type, stats, end cards, beat-synced cards | **HyperFrames** (HTML + GSAP) | Timing is plain numbers a script can generate from a transcript or beat map; `check` and `snapshot` catch problems before a render; alpha overlays come out directly |
| Many data-driven variants of one component, a reusable template with props, or something an editor or Player will reuse | **Remotion** (React) | Components and props are the unit; one template renders every variant; a React system may already exist |
| Procedural or generative graphics (particles, crowds, simulations, thousands of marks, shaders) | **Plain code drawing each frame as a pure function of time**, no framework: a `draw(t)` on a canvas (Node `skia-canvas`, or a headless-browser loop like `render.mjs`) or Python/PIL, frames piped to ffmpeg (`-c:v prores_ks -profile:v 4444` or VP9 with alpha for overlays) | Hand-written drawing beats animating thousands of DOM nodes, and the render loop is about 50 lines. Host it in an engine instead only when it shares a frame with that engine's type and timing |
| A one-off that only needs a still or a short loop from a design | the static renderer (`render.mjs`) or the engine already open for that piece | Fewest moving parts |

- **Footage is never cut in a motion engine.** Cut first (path table above),
  then lay graphics over it as a transparent overlay (ProRes 4444 or WebM with
  alpha).
- **Never animate on wall-clock time.** Whatever draws the frame (GSAP,
  React, plain canvas code) must render frame N the same way every time it is
  seeked to; that is what the engines guarantee and what a bare
  `requestAnimationFrame` loop does not.
- **One engine per piece; never build the same card in both.**
- **Both engines read the brand from generated token files; never type
  values.** Using an engine a repo has not used before is allowed: first add
  its token target to `brand/build.py` so the brand stays in one place, then
  note it in the repo's guide.

## Beat-locked promo, outline

1. Inventory the footage (probe, contact sheets, the source's own cuts).
2. Get the track, build the beat grid, choose the drop.
3. **Propose the strategy in plain language and wait for a yes**: length,
   structure, shots, copy, formats.
4. Write the cut list in beats after the drop and the card template in the
   brand's style.
5. Render a preview, look, fix, render finals, run delivery checks.

## Delivery

Master 4:5, 9:16 and 16:9 from one cut list and one card template. About
-14 LUFS, yuv420p limited range + AAC, uploads under ~38 MB for most social
APIs, 30fps unless the brand says otherwise. Keep source in-points away from
the source's own cuts (one-frame flashes hide there).
