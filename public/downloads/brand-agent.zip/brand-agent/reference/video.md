# Video

## Who does what

| Job | Tool |
| --- | --- |
| Cut footage to music | ffmpeg, driven by a cut list in beats |
| Cut footage on speech (talking head, interview) | a transcript-driven editor (e.g. the video-use skill) |
| Read a track: beats, drop, phrases | librosa beat grid |
| Graphics over footage: titles, lists, lower thirds, end cards | the repo's motion engine, rendered as an alpha overlay |
| Transcripts, voiceover, music beds | ElevenLabs (Scribe, TTS, Music) |
| Captions | last, over the finished cut |

## Pick the engine, one per piece

- **Footage is never cut in a motion engine.** Cut first, then lay
  graphics over it as a transparent overlay (ProRes 4444 or WebM with alpha).
- **HyperFrames** (HTML timelines): default for timeline graphics. Timing is
  plain numbers you can generate from a beat map; its `check` catches
  overlaps and contrast before rendering.
- **Remotion** (React): when you need many data-driven variants of one
  component, or a React system already exists.
- Write the choice in the project's notes. Never build the same card in both.
- Both engines read the brand from generated token files; never type values.

## Beat-locked promo, outline

1. Inventory the footage (probe, contact sheets, the source's own cuts).
2. Get the track, build the beat grid, choose the drop.
3. **Propose the strategy in plain language and wait for a yes**: length,
   structure, shots, copy, formats.
4. Write the cut list in beats after the drop and the card template in the
   brand's style.
5. Render a preview, look, fix, render finals, run delivery checks.

## Delivery

Master 4:5, 9:16 and 16:9 from one cut list and one card template. About
-14 LUFS, yuv420p limited range + AAC, uploads under ~38 MB for most social
APIs, 30fps unless the brand says otherwise. Keep source in-points away from
the source's own cuts (one-frame flashes hide there).
