# Architecture

## Repo skeleton

```
<brand>-brand/
  AGENTS.md            agent guide for every agent: read order, channels, gotchas
  CLAUDE.md            one line, `@AGENTS.md`, so Claude Code reads the same guide
  BRAND.md             rules, voice, and the canon's visual moves
  brand/
    tokens.json        every exact value (W3C design tokens format)
    build.py           generates each engine's token file from tokens.json
    channels.json      accounts and how to post to each
  canon/
    README.md          approved work, one note per piece on why it works
    claude-design/     mirror of the brand's Claude Design project (optional)
  guidelines/          the human-made source documents, never edited
  assets/              marks, fonts, imagery, footage (curated inputs)
  design-system/       generated: tokens.css, components.css, cards, templates
  social/<campaign>/   static pieces + POST.md per campaign
  print/  decks/       further static channels as needed
  video/               motion engine project(s), tools, projects/<slug>/
  ads/reports/         dated performance reports
  .env                 API keys (gitignored)
```

## The parts and why each exists

The point of a brand agent is quality, brand-consistent content at scale.
Content production is the heart of it; distribution (organic publishing and
paid social) and tracking support it. The brand core is the rules; the
design system is the parts built from them.

**Content production**

1. **Brand core.** Three files, three jobs. `tokens.json` holds values code
   needs. `BRAND.md` holds judgment code cannot hold. `canon/` holds
   examples, because agents copy examples far better than they follow
   adjectives. Without canon, output is in-palette but not on-brand.
2. **Design system.** The core expressed as HTML building blocks (classes
   named for the canon's moves, preview cards, templates for every format),
   synced to a Claude Design design-system project so the visual tool and
   the repo start from the same thing and a design can begin in either.
3. **Make: static.** HTML is the production format, because it is what
   Claude Design produces and what a headless browser renders exactly. One
   idea fans out to every format the platforms need, and an agent reviews
   every frame against the canon before anyone sees it.
4. **Make: video.** Cut footage with ffmpeg or a transcript tool; make
   graphics in one motion engine (HyperFrames for HTML timelines, Remotion
   for React components and many data-driven variants); composite as alpha.

**Distribution**

5. **Publishing.** Organic posting. A campaign manifest (`post.json`, with `POST.md` for people)
   and interchangeable adapters (scheduler API, browser automation, hand-off
   folder) so adding an account or a tool is a config change. Always behind
   the owner's approval.
6. **Paid social.** Meta Ads through its MCP connector: the campaigns that
   put the brand on paid social and their performance. Paid creative comes
   from the same design system. Run it read-only unless the owner decides
   otherwise (deny the mutating tools in the repo's agent settings); reports
   say "what to change in the next piece" and feed canon and `BRAND.md`.

**Tracking**

7. **Foundation.** Git gives history and undo: agents change many files at
   once, two sessions can collide, editors can autosave over each other.
   LFS keeps media out of the git objects. `AGENTS.md` tells an agent the
   read order and where things are; keep it short and point at files.

## Any agent

The skill follows the open SKILL.md format, so the same folder works in
Claude Code, Codex and Hermes. Install it once and link it into each agent's
skills folder (`~/.claude/skills`, `~/.codex/skills`, `~/.hermes/skills`,
`~/.agents/skills`). Repo instructions live in `AGENTS.md`, which Codex and
Hermes read directly and Claude Code imports from `CLAUDE.md`. Nothing in
the tools depends on one vendor: rendering is headless Chrome, tokens are
JSON, publishing is an HTTP API. Claude Design is an optional surface
synced from `design-system/`, never a requirement.

## Shared versus per-brand

- **Per brand (in the repo):** everything about how the brand looks and
  sounds, its keys, its accounts, its finished work.
- **Shared (in this skill):** the method, the renderer, the scaffolder, the
  templates for new repos. Improve the shared kit once and every brand gets it.
- A brand repo never copies another brand's files. Copy patterns, not files.
