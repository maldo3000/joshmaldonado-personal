# Static: posts, carousels, stories, slides, print

HTML is the production format. One file can hold a whole set (a carousel's
slides, a post and its story twin), each frame a fixed-size element with
`data-screen-label`.

## Render

```bash
cd ~/.claude/skills/brand-agent/scripts/static && npm install   # once
node ~/.claude/skills/brand-agent/scripts/static/render.mjs <file.html> <outDir> [--only "<label>"] [--scale 2]
```

- One PNG per frame, at the frame's CSS size.
- Claude Design decks (`<deck-stage>`) are stepped slide by slide with the
  player UI hidden and motion reduced, so nothing is caught mid-fade.
- A file with no frames (a web page) renders as one full-page `page.png`.
- Needs Google Chrome; `CHROME_PATH` overrides the location.

## Make a piece

1. Pick the template closest to the brief from `design-system/templates/`.
2. Copy it into the campaign folder (`social/<campaign>/`) and replace copy
   and imagery. Keep the structure.
3. Render, then **look at every frame**: overlaps, contrast, safe zones,
   minimum type size, the logo actually rendered.
4. Deliver at the platform's sizes (4:5 1080x1350 feed, 9:16 1080x1920
   story, 1:1, 16:9). Re-layout per format instead of cropping one.

## Print

Render at `--scale` high enough for 300 dpi at trim size, with bleed built
into the frame, then assemble PDFs (img2pdf or similar). Ask for the
printer's trim, bleed and color profile.
