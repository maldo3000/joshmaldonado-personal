#!/usr/bin/env python3
"""Publish a campaign from its post.json, through each account's adapter.

    publish.py <campaign-dir|post.json> list                 # accounts (+ live Postiz integrations)
    publish.py <campaign> dry [--only x,linkedin]            # build every payload, upload nothing
    publish.py <campaign> schedule --confirm [--only ...]    # upload media + schedule (postiz)
    publish.py <campaign> update --confirm [--only ...]      # re-send media/caption/date to queued posts
    publish.py <campaign> status                             # state of scheduled posts
    publish.py <campaign> handoff [--only ...]               # folder a person posts from

post.json (beside the campaign's POST.md) lists the posts; the brand's
brand/channels.json maps each channel id to an account and an adapter:

  postiz   Postiz public API. Key: POSTIZ_KEY env, else the nearest .env above.
  handoff  writes <campaign>/handoff/<channel>/ with media, caption.txt, when.txt.
  browser  no automation here: prints a checklist for an agent driving the
           platform's own scheduler, one approved post at a time.

schedule and update refuse to run without --confirm: the owner must have
approved these posts, accounts and times. Results are written back into
post.json under "scheduled" so update and status can find them.
"""
import argparse
import datetime as dt
import json
import mimetypes
import os
import shutil
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

# Postiz settings per platform. Per-post "settings" in post.json override these.
PLATFORM_SETTINGS = {
    "instagram": {"post_type": "post", "collaborators": []},
    "linkedin": {},
    "linkedin-page": {},
    "x": {"who_can_reply_post": "everyone", "community": ""},
    "tiktok": {
        "privacy_level": "PUBLIC_TO_EVERYONE", "duet": False, "stitch": False, "comment": True,
        "brand_content_toggle": False, "brand_organic_toggle": False,
        "autoAddMusic": "no", "content_posting_method": "DIRECT_POST", "isValidVideo": False,
    },
}


# ── loading ──────────────────────────────────────────────────────────────

def load_campaign(target):
    path = Path(target).expanduser().resolve()
    manifest = path if path.suffix == ".json" else path / "post.json"
    if not manifest.exists():
        sys.exit(f"no post.json at {manifest}")
    return manifest, json.loads(manifest.read_text())


def find_up(start, rel):
    for d in [start, *start.parents]:
        if (d / rel).exists():
            return d / rel
    return None


def load_channels(manifest):
    path = find_up(manifest.parent, "brand/channels.json")
    if not path:
        sys.exit("no brand/channels.json above this campaign; add one (see the skill's templates/brand/)")
    data = json.loads(path.read_text())
    return {a["id"]: a for a in data.get("accounts", [])}, data.get("defaults", {})


def postiz_key(manifest):
    key = os.environ.get("POSTIZ_KEY")
    env = None if key else find_up(manifest.parent, ".env")
    if env:
        for line in env.read_text().splitlines():
            if line.strip().startswith("POSTIZ_KEY="):
                key = line.split("=", 1)[1].strip().strip("'\"")
    if not key:
        sys.exit("POSTIZ_KEY not set (env var or the brand repo's .env)")
    return key


def utc(stamp):
    """ISO time with an offset (2026-09-29T17:10:00-04:00) -> Postiz UTC string."""
    when = dt.datetime.fromisoformat(stamp)
    if when.tzinfo is None:
        sys.exit(f"date needs a UTC offset: {stamp}")
    return when.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def caption_parts(post, base):
    """A caption is a string, a list (an X thread), or a captionFile."""
    if "captionFile" in post:
        return [(base / post["captionFile"]).read_text().strip()]
    cap = post.get("caption", "")
    return cap if isinstance(cap, list) else [cap]


def media_paths(post, base):
    paths = [(base / m).resolve() for m in post.get("media", [])]
    missing = [str(p) for p in paths if not p.exists()]
    if missing:
        sys.exit("missing media:\n  " + "\n  ".join(missing))
    return paths


# ── postiz ───────────────────────────────────────────────────────────────

class Postiz:
    def __init__(self, key):
        self.key = key
        self.base = os.environ.get("POSTIZ_URL", "https://api.postiz.com").rstrip("/") + "/public/v1"

    def req(self, method, path, data=None, headers=None):
        h = {"Authorization": self.key, "Accept": "application/json", **(headers or {})}
        body = data
        if data is not None and not isinstance(data, bytes):
            body = json.dumps(data).encode()
            h["Content-Type"] = "application/json"
        for attempt in range(4):
            request = urllib.request.Request(self.base + path, data=body, method=method, headers=h)
            try:
                with urllib.request.urlopen(request, timeout=300) as resp:
                    text = resp.read().decode()
                    return json.loads(text) if text else None
            except urllib.error.HTTPError as e:
                msg = e.read().decode()[:800]
                # The upload host occasionally 502s; retry gateway errors on upload only.
                if e.code in (502, 503, 504) and path == "/upload" and attempt < 3:
                    time.sleep(3 * (attempt + 1))
                    continue
                sys.exit(f"{method} {path} -> {e.code}: {msg}")

    def upload(self, path):
        boundary = uuid.uuid4().hex
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{path.name}"\r\n'
                f"Content-Type: {ctype}\r\n\r\n").encode() + path.read_bytes() + f"\r\n--{boundary}--\r\n".encode()
        out = self.req("POST", "/upload", body, {"Content-Type": f"multipart/form-data; boundary={boundary}"})
        print(f"  uploaded {path.name} -> {out.get('id')}")
        return {"id": out["id"], "path": out["path"]}

    def integrations(self):
        return {i["id"]: i for i in self.req("GET", "/integrations")}

    def posts_between(self, dates):
        days = sorted(d[:10] for d in dates)
        out = self.req("GET", f"/posts?startDate={days[0]}T00:00:00.000Z&endDate={days[-1]}T23:59:59.000Z")
        return out.get("posts", []) if isinstance(out, dict) else (out or [])


def postiz_entry(post, account, campaign, base, media, existing=None):
    platform = account["platform"]
    settings = {**PLATFORM_SETTINGS.get(platform, {}), **account.get("settings", {}), **post.get("settings", {})}
    if platform == "tiktok":
        settings.setdefault("title", post.get("title") or campaign.get("title", ""))
    parts = caption_parts(post, base)
    value = [{"content": parts[0], "image": media}] + [{"content": p, "image": []} for p in parts[1:]]
    entry = {"integration": {"id": account["postizIntegration"]}, "value": value, "settings": settings}
    if existing:  # upsert in place: current group + post id
        entry["group"] = existing["group"]
        value[0]["id"] = existing["id"]
    return entry


# ── commands ─────────────────────────────────────────────────────────────

def selected(campaign, accounts, only):
    posts = []
    for post in campaign["posts"]:
        if only and post["channel"] not in only:
            continue
        account = accounts.get(post["channel"])
        if not account:
            sys.exit(f"channel '{post['channel']}' is not in brand/channels.json")
        posts.append((post, account))
    if not posts:
        sys.exit("no posts selected")
    return posts


def cmd_list(manifest, campaign, accounts, args):
    print(f"Campaign: {campaign.get('campaign', manifest.parent.name)}")
    for post in campaign["posts"]:
        a = accounts.get(post["channel"], {})
        print(f"  {post['channel']:16} {post['date']}  {a.get('adapter', '?'):8} {len(post.get('media', []))} media")
    if any(a.get("adapter") == "postiz" for a in accounts.values()):
        live = Postiz(postiz_key(manifest)).integrations()
        print("Postiz integrations:")
        for i in live.values():
            print(f"  {i['id']}  {i.get('identifier', ''):22} {i.get('name')}  disabled={i.get('disabled')}")


def postiz_payloads(manifest, campaign, posts, dry, existing=None):
    base = manifest.parent
    client = None if dry else Postiz(postiz_key(manifest))
    by_date = {}
    for post, account in posts:
        paths = media_paths(post, base)
        media = [{"id": "DRY", "path": p.name} for p in paths] if dry else [client.upload(p) for p in paths]
        found = (existing or {}).get(post["channel"])
        by_date.setdefault(utc(post["date"]), []).append(
            (post["channel"], postiz_entry(post, account, campaign, base, media, found)))
    return client, by_date


def cmd_dry(manifest, campaign, accounts, args):
    posts = selected(campaign, accounts, args.only)
    pz = [(p, a) for p, a in posts if a["adapter"] == "postiz"]
    if pz:
        _, by_date = postiz_payloads(manifest, campaign, pz, dry=True)
        for date, group in sorted(by_date.items()):
            payload = {"type": "schedule", "date": date, "shortLink": False, "tags": [], "posts": [e for _, e in group]}
            print(json.dumps(payload, indent=1, ensure_ascii=False))
    for post, account in posts:
        if account["adapter"] != "postiz":
            print(f"{post['channel']}: adapter '{account['adapter']}' (run `{account['adapter']}`)")


def require_confirm(args, defaults):
    if defaults.get("requireApproval", True) and not args.confirm:
        sys.exit("refusing: pass --confirm once the owner has approved these posts, accounts and times")


def cmd_schedule(manifest, campaign, accounts, args, defaults):
    require_confirm(args, defaults)
    posts = [(p, a) for p, a in selected(campaign, accounts, args.only) if a["adapter"] == "postiz"]
    if not posts:
        sys.exit("no postiz posts selected")
    client, by_date = postiz_payloads(manifest, campaign, posts, dry=False)
    record = campaign.setdefault("scheduled", {})
    for date, group in sorted(by_date.items()):
        payload = {"type": "schedule", "date": date, "shortLink": False, "tags": [], "posts": [e for _, e in group]}
        out = client.req("POST", "/posts", payload)
        print("scheduled", date, json.dumps(out)[:600])
        # Keep the raw response so ids are never lost, then map what we can.
        campaign.setdefault("responses", []).append({"date": date, "response": out})
        results = out if isinstance(out, list) else [out]
        for (channel, _), res in zip(group, results):
            if isinstance(res, dict):
                record[channel] = {"id": res.get("postId") or res.get("id"), "group": res.get("group"), "date": date}
    manifest.write_text(json.dumps(campaign, indent=2, ensure_ascii=False) + "\n")
    print(f"recorded ids in {manifest}")


def queued(client, campaign, posts):
    """Current Postiz state for this campaign's posts, matched by recorded id."""
    ids = {v.get("id"): ch for ch, v in campaign.get("scheduled", {}).items() if v.get("id")}
    if not ids:
        sys.exit("nothing recorded under 'scheduled' in post.json")
    live = client.posts_between([utc(p["date"]) for p, _ in posts])
    return {ids[p["id"]]: p for p in live if p.get("id") in ids}


def cmd_update(manifest, campaign, accounts, args, defaults):
    require_confirm(args, defaults)
    posts = [(p, a) for p, a in selected(campaign, accounts, args.only) if a["adapter"] == "postiz"]
    client = Postiz(postiz_key(manifest))
    current = queued(client, campaign, posts)  # groups change when a post is re-saved: always re-read
    posts = [(p, a) for p, a in posts if p["channel"] in current]
    _, by_date = postiz_payloads(manifest, campaign, posts, dry=False, existing=current)
    for date, group in sorted(by_date.items()):
        payload = {"type": "schedule", "date": date, "shortLink": False, "tags": [], "posts": [e for _, e in group]}
        print("updated", date, json.dumps(client.req("POST", "/posts", payload))[:400])


def cmd_status(manifest, campaign, accounts, args, defaults):
    posts = selected(campaign, accounts, args.only)
    client = Postiz(postiz_key(manifest))
    current = queued(client, campaign, posts)
    for channel in campaign.get("scheduled", {}):
        p = current.get(channel)
        print(f"  {channel:16} {p.get('state') if p else 'not found'}  {p.get('publishDate', '') if p else ''}")


def cmd_handoff(manifest, campaign, accounts, args, defaults):
    base = manifest.parent
    for post, account in selected(campaign, accounts, args.only):
        out = base / "handoff" / post["channel"]
        out.mkdir(parents=True, exist_ok=True)
        for i, src in enumerate(media_paths(post, base), 1):
            shutil.copy2(src, out / f"{i:02d}{src.suffix}")
        (out / "caption.txt").write_text("\n\n---\n\n".join(caption_parts(post, base)) + "\n")
        (out / "when.txt").write_text(f"{post['date']}\naccount: {account.get('handle', account['id'])}\n")
        print(f"  {post['channel']}: {out}")


def cmd_browser(manifest, campaign, accounts, args, defaults):
    base = manifest.parent
    print("Browser adapter: post each item in the platform's own scheduler.")
    print("Ask the owner to approve EACH post (account, time, caption, media) before submitting it.\n")
    for post, account in selected(campaign, accounts, args.only):
        if account["adapter"] != "browser":
            continue
        print(f"- {post['channel']} as {account.get('handle', account['id'])} at {post['date']}")
        for p in media_paths(post, base):
            print(f"    media: {p}")
        print("    caption:\n      " + "\n      ".join(caption_parts(post, base)[0].splitlines()))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("campaign")
    ap.add_argument("command", choices=["list", "dry", "schedule", "update", "status", "handoff", "browser"])
    ap.add_argument("--only", type=lambda s: set(s.split(",")))
    ap.add_argument("--confirm", action="store_true")
    args = ap.parse_args()
    manifest, campaign = load_campaign(args.campaign)
    accounts, defaults = load_channels(manifest)
    if args.command == "list":
        return cmd_list(manifest, campaign, accounts, args)
    if args.command == "dry":
        return cmd_dry(manifest, campaign, accounts, args)
    {"schedule": cmd_schedule, "update": cmd_update, "status": cmd_status,
     "handoff": cmd_handoff, "browser": cmd_browser}[args.command](manifest, campaign, accounts, args, defaults)


if __name__ == "__main__":
    main()
