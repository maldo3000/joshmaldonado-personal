#!/usr/bin/env python3
"""Check a brand repo against the brand-agent standard.

    python3 audit.py <repo> [<repo> ...]

Prints one line per layer (done / partial / missing) and the next actions.
Read-only: it never changes the repo.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

MARK = {"done": "✓", "partial": "½", "missing": "✗"}


def run(cmd, cwd):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return r.returncode, r.stdout.strip()


def read_json(path):
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def audit(repo: Path):
    rows, todo = [], []

    def row(layer, state, detail, fix=None):
        rows.append((layer, state, detail))
        if fix and state != "done":
            todo.append(f"{layer}: {fix}")

    # 1 Foundation
    git = (repo / ".git").exists()
    attrs = (repo / ".gitattributes").read_text() if (repo / ".gitattributes").exists() else ""
    ignore = (repo / ".gitignore").read_text() if (repo / ".gitignore").exists() else ""
    dirty = len(run(["git", "status", "--porcelain"], repo)[1].splitlines()) if git else 0
    guide = (repo / "AGENTS.md").exists()
    checks = [git, "filter=lfs" in attrs, ".env" in ignore, guide]
    state = "done" if all(checks) and dirty == 0 else "partial" if git else "missing"
    detail = f"git {'yes' if git else 'no'}, LFS rules {'yes' if checks[1] else 'no'}, .env ignored {'yes' if checks[2] else 'no'}, AGENTS.md {'yes' if guide else 'no (CLAUDE.md only)' if (repo / 'CLAUDE.md').exists() else 'no'}"
    detail += f", {dirty} uncommitted" if dirty else ""
    row("Foundation", state, detail, "git + LFS from templates/repo, commit pending work (reference/repo-setup.md)")

    # 2 Brand core
    tokens = read_json(repo / "brand/tokens.json") if (repo / "brand/tokens.json").exists() else None
    build_ok = None
    if (repo / "brand/build.py").exists():
        build_ok = run([sys.executable, "brand/build.py", "--check"], repo)[0] == 0
    brand_md = (repo / "BRAND.md").read_text() if (repo / "BRAND.md").exists() else ""
    canon = (repo / "canon/README.md").read_text() if (repo / "canon/README.md").exists() else ""
    canon_pieces = len(re.findall(r"^\*\*[^*]+\*\*", canon, re.M))
    parts = {
        "tokens.json": bool(tokens and "color" in tokens),
        "build.py in sync": bool(build_ok),
        "BRAND.md": bool(brand_md),
        "practice section": "how it looks in practice" in brand_md.lower(),
        f"canon ({canon_pieces} pieces)": canon_pieces >= 3,
    }
    have = sum(parts.values())
    row("Brand core", "done" if have == len(parts) else "partial" if have else "missing",
        ", ".join(f"{k} {'yes' if v else 'no'}" for k, v in parts.items()),
        "tokens.json + build.py, BRAND.md ending in 'How it looks in practice', canon/ with notes (reference/brand-core.md)")

    # 3 Design system
    ds = repo / "design-system"
    cards = [p for p in ds.rglob("*.html") if p.read_text(errors="ignore").lstrip().startswith("<!-- @dsCard")] if ds.exists() else []
    templates = list((ds / "templates").glob("*.html")) if (ds / "templates").exists() else []
    parts = [(ds / "tokens.css").exists(), (ds / "components.css").exists(), (ds / "README.md").exists(), len(cards) >= 3, len(templates) >= 1]
    row("Design system", "done" if all(parts) else "partial" if any(parts) else "missing",
        f"{len(cards)} cards, {len(templates)} templates" if ds.exists() else "no design-system/",
        "components.css, cards and templates rebuilt from canon, then /design-sync (reference/design-system.md)")

    # 4 Static
    static_dirs = [d for d in ("social", "print", "decks") if (repo / d).exists()]
    html = [p for d in static_dirs for p in (repo / d).rglob("*.html")]
    studio = (repo / "studio").exists()
    state = "done" if templates and static_dirs else "partial" if static_dirs or studio else "missing"
    row("Make: static", state, f"channels {static_dirs or 'none'}, {len(html)} HTML pieces" + (", studio/" if studio else ""),
        "a social/ channel built on design-system templates (reference/static.md)")

    # 5 Video
    video = repo / "video"
    engines = [e for e in ("hyperframes", "remotion") if (video / e).exists()]
    row("Make: video", "done" if engines else "partial" if video.exists() else "missing",
        f"engines {engines or 'none'}", "a video/ channel with one motion engine (reference/video.md)")

    # 6 Publish
    channels = read_json(repo / "brand/channels.json") if (repo / "brand/channels.json").exists() else None
    accounts = (channels or {}).get("accounts", [])
    manifests = [p for p in repo.rglob("post.json") if "node_modules" not in p.parts]
    state = "done" if accounts and manifests else "partial" if accounts or manifests else "missing"
    row("Publish", state, f"{len(accounts)} accounts in channels.json, {len(manifests)} campaign manifests",
        "brand/channels.json with every account + post.json per campaign (reference/publish.md)")

    # 7 Learn
    reports = list((repo / "ads/reports").glob("*.md")) if (repo / "ads/reports").exists() else []
    mcp = (repo / ".mcp.json").exists()
    row("Learn", "done" if reports and mcp else "partial" if reports or mcp else "missing",
        f"{len(reports)} reports, ads MCP {'connected' if mcp else 'not connected'}",
        "a read-only ads connection and dated reports (reference/learn.md)")

    print(f"\n{repo.name}")
    for layer, state, detail in rows:
        print(f"  {MARK[state]} {layer:14} {detail}")
    if todo:
        print("  next:")
        for t in todo:
            print(f"    - {t}")
    return all(s == "done" for _, s, _ in rows)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    results = [audit(Path(p).expanduser().resolve()) for p in sys.argv[1:]]
    sys.exit(0 if all(results) else 1)
