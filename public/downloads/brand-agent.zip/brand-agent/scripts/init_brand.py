#!/usr/bin/env python3
"""Scaffold a new brand agent repo.

    python3 init_brand.py <path> --name "Brand Name" [--url example.com] [--prefix b] [--no-git]

Creates the standard skeleton (brand core, canon, design system, social,
guidelines, assets), fills {{BRAND}} / {{URL}} placeholders, runs the first
token build, and sets up git + LFS. Refuses to write into a non-empty folder.
Next steps are printed at the end.
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
T = SKILL / "templates"

TEXT_SUFFIXES = {".md", ".html", ".css", ".json", ".py"}


def copy_tree(src: Path, dst: Path, subs: dict):
    for path in sorted(src.rglob("*")):
        if path.is_dir():
            continue
        target = dst / path.relative_to(src)
        target.parent.mkdir(parents=True, exist_ok=True)
        if path.suffix in TEXT_SUFFIXES:
            text = path.read_text()
            for key, value in subs.items():
                text = text.replace(key, value)
            target.write_text(text)
        else:
            shutil.copy2(path, target)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--name", required=True)
    ap.add_argument("--url", default="example.com")
    ap.add_argument("--prefix", default="b", help="CSS variable prefix (default b)")
    ap.add_argument("--no-git", action="store_true")
    args = ap.parse_args()

    root = Path(args.path).expanduser().resolve()
    if root.exists() and any(root.iterdir()):
        sys.exit(f"{root} is not empty; scaffold into a new folder")
    root.mkdir(parents=True, exist_ok=True)
    subs = {"{{BRAND}}": args.name, "{{URL}}": args.url}

    copy_tree(T / "brand", root / "brand", subs)
    copy_tree(T / "canon", root / "canon", subs)
    copy_tree(T / "design-system", root / "design-system", subs)
    copy_tree(T / "social", root / "social" / "_template", subs)
    for name in ("BRAND.md", "AGENTS.md"):
        (root / name).write_text((T / name).read_text().replace("{{BRAND}}", args.name))
    (root / "CLAUDE.md").write_text("@AGENTS.md\n\nAGENTS.md is the agent guide for every agent; this file imports it for Claude Code.\n")
    shutil.copy2(T / "repo/gitignore", root / ".gitignore")
    shutil.copy2(T / "repo/gitattributes", root / ".gitattributes")
    (root / ".env.example").write_text("# Copy to .env (gitignored, chmod 600). Never commit or share .env.\nPOSTIZ_KEY=\n")
    for folder in ("guidelines", "assets/brand", "assets/fonts", "assets/imagery", "ads/reports"):
        (root / folder).mkdir(parents=True, exist_ok=True)
        (root / folder / ".gitkeep").touch()

    tokens_path = root / "brand/tokens.json"
    tokens = json.loads(tokens_path.read_text())
    tokens["brand"]["name"]["$value"] = args.name
    tokens["brand"]["url"]["$value"] = args.url
    tokens_path.write_text(json.dumps(tokens, indent=2, ensure_ascii=False) + "\n")
    build = root / "brand/build.py"
    build.write_text(build.read_text().replace('PREFIX = "b"', f'PREFIX = "{args.prefix}"'))
    if args.prefix != "b":
        for css in (root / "design-system").rglob("*"):
            if css.suffix in {".css", ".html", ".md"}:
                css.write_text(re.sub(r"(?<![A-Za-z0-9])b-", f"{args.prefix}-", css.read_text()))
    subprocess.run([sys.executable, str(build)], cwd=root, check=True)

    if not args.no_git:
        subprocess.run(["git", "init", "-q", "-b", "main"], cwd=root, check=True)
        lfs = subprocess.run(["git", "lfs", "install", "--local"], cwd=root, capture_output=True)
        if lfs.returncode != 0:
            print("warning: git-lfs not installed; media will not be stored in LFS until it is")
        subprocess.run(["git", "add", "-A"], cwd=root, check=True)
        subprocess.run(["git", "commit", "-q", "-m", f"Scaffold {args.name} brand agent"], cwd=root, check=True)

    print(f"""
Scaffolded {args.name} at {root}

Next:
  1. Put the guidelines in guidelines/, marks in assets/brand/, fonts in assets/fonts/.
  2. Fill brand/tokens.json from the guidelines, then python3 brand/build.py.
  3. Gather approved work into canon/ and write a note per piece (canon/README.md).
  4. Write BRAND.md, ending with "How it looks in practice" (the canon's moves).
  5. Rebuild design-system/components.css and templates/ from the canon; render and compare.
  6. Sync design-system/ to Claude Design with /design-sync.
""")


if __name__ == "__main__":
    main()
