#!/usr/bin/env node
// Render every frame in an HTML design to a PNG at its native size.
//
//   node render.mjs <design.html> [outDir] [--only "<label substring>"] [--scale 1] [--sheet]
//
// A frame is any element with data-screen-label (the Claude Design convention;
// deck slides get it from deck-stage.js at runtime,
// and design-system templates use it too). Each becomes <outDir>/<label>.png at
// the element's own CSS size, e.g. a 1080x1350 div -> a 1080x1350 PNG.
// A file with no frames (a web page) renders as one full-page page.png.
// --sheet also writes <outDir>/sheet.png: every frame side by side at one
// height with its label, for comparing directions against each other or canon.
// Works on Claude Design .dc.html exports (their support.js runs as usual) and
// on plain HTML. Needs Google Chrome; set CHROME_PATH to use another build.
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import puppeteer from "puppeteer-core";

const args = process.argv.slice(2);
const flag = (name) => {
  const i = args.indexOf(name);
  if (i === -1) return undefined;
  const value = args[i + 1];
  args.splice(i, 2);
  return value;
};
const only = flag("--only");
const scale = Number(flag("--scale") ?? 1);
const wantSheet = args.includes("--sheet");
if (wantSheet) args.splice(args.indexOf("--sheet"), 1);
const [input, outArg] = args;
if (!input) {
  console.error('usage: render.mjs <design.html> [outDir] [--only "<label>"] [--scale 1]');
  process.exit(2);
}
const file = path.resolve(input);
const outDir = path.resolve(outArg ?? path.join(path.dirname(file), "renders", path.basename(file).replace(/(\.dc)?\.html$/, "")));
fs.mkdirSync(outDir, { recursive: true });

const executablePath =
  process.env.CHROME_PATH ?? "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const browser = await puppeteer.launch({
  executablePath,
  headless: true,
  args: ["--allow-file-access-from-files", "--font-render-hinting=none", "--force-color-profile=srgb"],
});
try {
  const page = await browser.newPage();
  await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: scale });
  // Reduced motion: entrance animations show their end state, never mid-fade.
  await page.emulateMediaFeatures([{ name: "prefers-reduced-motion", value: "reduce" }]);
  await page.goto(pathToFileURL(file).href, { waitUntil: "networkidle0", timeout: 60000 });
  await page.evaluate(async () => {
    await document.fonts.ready;
    await Promise.all(
      [...document.images].map((img) => (img.complete ? null : new Promise((r) => (img.onload = img.onerror = r)))),
    );
  });

  const frames = await page.$$("[data-screen-label]");
  const written = [];
  let count = 0;
  for (const frame of frames) {
    const label = await frame.evaluate((el) => el.getAttribute("data-screen-label"));
    if (only && !label.includes(only)) continue;
    // Deck slides: the <deck-stage> player shows one slide at a time, so step
    // it to this slide and let the transition settle before capturing.
    const inDeck = await frame.evaluate(async (el) => {
      const stage = el.closest("deck-stage");
      if (!stage || typeof stage.goTo !== "function") return false;
      if (!stage.dataset.renderPrepared) {
        // Hide the player's own UI (rail, nav pill, menus) so only the slide shows.
        stage.setAttribute("no-rail", "");
        const style = document.createElement("style");
        style.textContent = "[data-omelette-chrome]{display:none!important}";
        (stage.shadowRoot ?? document.head).appendChild(style);
        stage.dataset.renderPrepared = "1";
      }
      const slides = [...stage.children].filter((c) => c.tagName === "SECTION");
      stage.goTo(slides.indexOf(el));
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      return true;
    });
    if (inDeck) await new Promise((r) => setTimeout(r, 700));
    const name = label.replace(/[\/:*?"<>|]/g, "-").replace(/\s+/g, " ").trim();
    const target = path.join(outDir, `${name}.png`);
    await frame.screenshot({ path: target });
    console.log(target);
    written.push({ label, target });
    count += 1;
  }
  if (!count && frames.length) {
    console.error(`no frame label matches "${only}"`);
    process.exitCode = 1;
  } else if (!count) {
    // No frames (a web page or an unlabeled canvas): capture the whole page.
    const target = path.join(outDir, "page.png");
    await page.screenshot({ path: target, fullPage: true });
    console.log(target);
  }
  if (wantSheet && written.length) {
    const sheet = await browser.newPage();
    await sheet.setViewport({ width: 2400, height: 800, deviceScaleFactor: 1 });
    const cells = written
      .map(({ label, target }) => `<figure><img src="data:image/png;base64,${fs.readFileSync(target).toString("base64")}"><figcaption>${label.replace(/</g, "&lt;")}</figcaption></figure>`)
      .join("");
    await sheet.setContent(
      `<html><body style="margin:0;background:#2a2a2a;font:13px -apple-system,Helvetica,sans-serif;color:#ddd">
       <div style="display:flex;flex-wrap:wrap;gap:24px;padding:24px;width:2352px">${cells}</div>
       <style>figure{margin:0}img{height:560px;display:block;box-shadow:0 0 0 1px #444}figcaption{margin-top:8px}</style>
       </body></html>`,
      { waitUntil: "load" },
    );
    const target = path.join(outDir, "sheet.png");
    await sheet.screenshot({ path: target, fullPage: true });
    console.log(target);
  }
} finally {
  await browser.close();
}
